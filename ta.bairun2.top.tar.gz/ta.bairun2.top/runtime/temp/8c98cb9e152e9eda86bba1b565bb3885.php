<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:74:"/www/wwwroot/ta.bairun2.top/public/../application/admin/view/ideas/add.php";i:1575280981;s:17:"common/header.php";i:1574668111;s:15:"common/foot.php";i:1571793815;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title>Home</title>

    <!--Begin  Page Level  CSS -->
    <link href="/static/assets/plugins/morris-chart/morris.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"/>
     <!--End  Page Level  CSS -->
    <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
    <script type="text/javascript" src="jquery-2.1.1.min.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
    #tag{
      margin-top:0px;

    }
    #tag font{
      margin:0px 5px 0px 5px;
      display:inline-block;
      width:60px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: black;
      background-color: #eee;
      overflow: hidden;
    }
</style>
</head>
<script src="/static/layui/layui.js"></script>
<body class="sticky-header">


    <!--Start left side Menu-->
    <div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="/static/assets/images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="/static/assets/images/logo-icon.png" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list"><a href="<?php echo url('Index/index'); ?>"><i class="icon-layers"></i> <span>广告组</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Index/index'); ?>"> Buttons</a></li>
                        <li><a href="<?php echo url('Index/index'); ?>"> Panels</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="<?php echo url('Plan/index'); ?>"><i class="icon-grid"></i> <span>广告计划</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Plan/index'); ?>"> Basic Table</a></li>
                        <li><a href="<?php echo url('Plan/index'); ?>">Responsive Table</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>广告创意</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Inbox</a></li>
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Compose Mail</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>Excel批量上传</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Batch/index'); ?>"> 批量创建广告组</a></li>
                        <li><a href="<?php echo url('Batch/plan_up'); ?>"> 批量创建广告计划</a></li>
                        <li><a href="<?php echo url('Batch/ideas_up'); ?>"> 批量创建广告创意</a></li>
                    </ul>
                </li>
            </ul>
            <!--End sidebar nav-->

        </div>
    </div>
    <!--End left side menu-->
    
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <a class="toggle-btn"><i class="fa fa-bars"></i></a>

            <form class="searchform">
                <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
            </form>

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-tasks"></i>
                            <span class="badge">8</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                            <h5 class="title">You have 8 pending task</h5>
                            <ul class="dropdown-list">
                            <li class="notification-scroll-list notification-list ">
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa  fa-shopping-cart noti-primary"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">A new order has been placed.</h5>
                                        <p class="m-0">
                                            <small>29 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-check noti-success"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Databse backup is complete</h5>
                                        <p class="m-0">
                                            <small>12 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-user-plus noti-info"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New user registered</h5>
                                        <p class="m-0">
                                             <small>17 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                                <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-diamond noti-danger"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Database error.</h5>
                                        <p class="m-0">
                                             <small>11 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-cog noti-warning"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New settings</h5>
                                        <p class="m-0">
                                             <small>18 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                             </li>
                             <li class="last"> <a href="#">View all notifications</a> </li>
              </ul>
                        </div>
                    </li>
                    
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge">4</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                         <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
             <li class="message-list message-scroll-list">
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-8.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">15 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-7.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">10 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                         
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
            </li>
            <li class="last"> <a  href="#">All Messages</a> </li>
          </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="/static/assets/images/users/avatar-6.jpg" alt="" />
                            <?php echo \think\Request::instance()->cookie('advertiser_id'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                          <li> <a href="#"> <i class="fa fa-wrench"></i> <?php echo \think\Request::instance()->cookie('advertiser_id'); ?> </a> </li>
                          <!-- <li> <a href="#"> <i class="fa fa-user"></i> Profile </a> </li>
                          <li> <a href="#"> <i class="fa fa-info"></i> Help </a> </li> -->
                          <li> <a href="<?php echo url('index/exit'); ?>"> <i class="fa fa-lock"></i> Logout </a> </li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>
        <!-- header section end-->
        <!--body wrapper start-->
        <div class="wrapper">

        <!-- <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a> -->
<!--Start row-->
             <div class="row">
                 <div class="col-md-12">
                   <div class="white-box">
                     <h2 class="header-title">创建广告创意</h2>
                       
                        <form action="<?php echo url('Ideas/doadd'); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                          <div class="form-group">
                            <label class="col-md-2 control-label">广告主ID</label>
                            <div class="col-md-10">
                              <input class="form-control" name="advertiser_id" value="<?php echo \think\Request::instance()->cookie('advertiser_id'); ?>" type="text" readonly="">
                            </div>
                          </div>


                          <div class="form-group">
                            <label class="col-sm-2 control-label">广告计划</label>
                            <div class="col-sm-10">
                              <select class="form-control tg_type" name="ad_id" onchange="tgmds()">
                                <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $vo['pid']; ?>"><?php echo $vo['name']; ?></option>/
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                              </select>
                            </div>
                          </div>
                          <script>
                                function tgmds(){
                                  var pid = $('.tg_type').val();
                                   $.get("<?php echo url('Ajax/get_landing_type'); ?>",{pid:pid},function(data){
                                        //alert('Ajax从服务器端返回来的值是：'+data);
                                        if(data!='error'){
                                          console.log(data);
                                        //$('.title_f').html(data.ideas_type_name);
                                        $('#zhi').html(data.type_name);
                                        $('#zhi').val(data.type);
                                        $('.tgmm').show();

                                        }
                                     });
                                }
                          </script>

                          <div class="form-group tgmm" style="display: none;" >
                            <label class="col-sm-2 control-label">广告推广目的</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="ad_id">
                                <option value="" id="zhi"></option>/
                              </select>
                            </div>
                          </div>

                          
                        <!--   <div class="form-group">
                            <label class="col-md-2 control-label" for="example-email">投放位置</label>
                            <div class="col-md-10">
                              <input id="example-email" name="inventory_type" class="form-control" placeholder="" type="text">
                            </div>
                          </div> -->




                          <div class="form-group">
                            <label class="col-sm-2 control-label" >投放位置</label>
                            <div class="col-sm-10">
                             <select name="inventory_type" id="tfwz" onchange="tf()" value="" style="margin: 0px;padding: 0px;float: left;height: 34px;">
                            <option id="ys" value="1" selected>优选广告位</option>
                            <option id="zys" value="2">按媒体指定位置</option>
                            <option id="zys" value="3">按场景指定位置</option>
                          </select></div>
                          <div class="app" style="margin-left:18.5%;margin-top: 2.5%;display:none;">
                          	<table>
                          		<th>APP名称</th>
                          		<tr>
                          			<td><input type="checkbox" name="app_name[0]" value="jrtt" title="今日头条" lay-skin="primary" checked>今日头条</td>
								</tr><tr>
                          			<td><input type="checkbox" name="app_name[1]" value="xgsp" title="西瓜视频" lay-skin="primary"> 西瓜视频</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[2]" value="hssp" title="火山小视频" lay-skin="primary" > 火山小视频</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[3]" value="dy" title="抖音" lay-skin="primary" > 抖音</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[4]" value="csj" title="穿山甲" lay-skin="primary" > 穿山甲</td>
                          		</tr>
                          	</table>
                            </div>
                          <div class="changjing" style="margin-left:18.5%;margin-top: 2.5%;display:none;">
                          	<table>
                          		<th>位置选择</th>
                          		<tr>
                          			<td><input type="checkbox" name="place[0]" title="沉浸式竖版视频场景" lay-skin="primary" checked>沉浸式竖版视频场景</td>
								</tr><tr>
                          			<td><input type="checkbox" name="place[1]" title="信息流场景" lay-skin="primary"> 信息流场景</td>
								</tr><tr>
									<td><input type="checkbox" name="place[2]" title="视频后贴和尾帧场景" lay-skin="primary" > 视频后贴和尾帧场景</td>
								</tr>
                          	</table>
                            </div>

                        </div>


							<script>
                            // function sel(){
                            //   //alert($("#aab").val());
                            //    if($("#aab").val()=='0571'){
                            //  // alert('aa')
                            //   $('.y_cont').attr('placeholder',' 请输入预算，不少于200元，不超过9999999.99元');
                            //  }
                            // if($("#aab").val()=='010'){
                            //   $('.y_cont').attr('placeholder',' 请输入预算，不少于100元，不超过9999999.99元');
                            //    }
                            // }
                            //removeAttr() 方法从被选元素中移除属性。
                            function tf(){
                            	if($('#tfwz').val()=='2'){
                            		$('.changjing').hide();
                            		$('.app').show();
                            	}
                            	if($('#tfwz').val()=='3'){
                            		$('.app').hide();
                            		$('.changjing').show();
                            	}
                            	if($('#tfwz').val()=='1'){
                            		$('.app').hide();
                            		$('.changjing').hide();
                            	}
                            }
                          </script>



                            <div class="form-group">
                            <label class="col-sm-2 control-label">创意分类</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="third_industry_id" style="width: 20%;float: left;" id="yiji" onchange="id_type()">
                                <?php if(is_array($industry_data) || $industry_data instanceof \think\Collection || $industry_data instanceof \think\Paginator): $i = 0; $__LIST__ = $industry_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $vo['industry_id']; ?>"><?php echo $vo['industry_name']; ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                              </select> 
                              <select class="form-control" name="third_industry_id" style="width: 20%;float: left;display: none;" id="second_industry" onchange="second_data()">
                                  <!-- <option value="3">3</option> -->
                              </select>
                              <select class="form-control" name="third_industry_id" style="width: 20%;float: left;display: none;" id="third_industry">
                                 <!--  <option value="3">3</option> -->
                                  
                              </select>
                            </div>
                          </div>
                            <script>
                              function fl(){
                                $('#ii').show();
                              }
                            </script>
                          <div class="form-group">
                            <label class="col-sm-2 control-label" >创意标签</label>
                            <div class="col-sm-10">
                         <!-- <input type="submit" style="margin: 0px;padding: 0px;float: left;height: 34px;border-right: 0px;width: 60px;">  -->
                         <a href="javascript:;" style="margin: 0px;padding: 0px;float: left;height: 34px;width: 80px;background-color: rgb(95,184,150);text-align: center;line-height: 34px;color: white;border-right: 0px;border-color: rgb(169,169,169);" onclick="add_type()">添加标签</a>
                          <input class="bq_type" type="text" name="title"   placeholder=" 最多20个标签，每个不超10字
" autocomplete="off" class="y_cont" style="margin:0px;padding: 0px;float: left;height: 34px;width: 50%;" >     
                            </div>

                            <div id="tag" style="margin-left:18.5%;margin-top: 3%;width: 40%;" value="标签" name="tag">
                            <p>已选标签：</p>
                            <!-- <table style="" class="table table-hover" id="tb">
                            	<tr>
                            		<td>已选标签</td>
                            	</tr> -->
                            
                            <!-- </table> -->
                            <?php if(is_array($tag_data) || $tag_data instanceof \think\Collection || $tag_data instanceof \think\Paginator): $i = 0; $__LIST__ = $tag_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <font name="bq1" value="1111111111"><?php echo $vo['name']; ?><input type="hidden" name="ad_keywords[<?php echo $vo['id']; ?>]" value="<?php echo $vo['id']; ?>"></font>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                          </div>
                          <script>
                          function add_type(){
                            	 var name = $('.bq_type').val();
                                $.get("<?php echo url('Ajax/index'); ?>",{name:name},function(data){
                                        //alert('Ajax从服务器端返回来的值是：'+data);
                                        console.log(data);
                                        if(data == 'success'){
                                         $('#tag').append(`<font >`+ name +`</font>`);
                                        }
                                     });
                            	var a = $("#tb").find("tr").length;
                            	console.log(a);
                             }

                          </script>

                        <!--   <div class="form-group">
                            <label class="col-md-2 control-label">投放时间</label>
                            <div class="col-md-10">
                               <input type="text" placeholder=" YY/mm/dd/ H:i:s" style="width: 35%;height:34px;margin-right: 0px;padding-right: 0px;" name="stat_time" class="layui-input1" id="test1"> &nbsp;&nbsp;-&nbsp;&nbsp;
                                <input type="text" placeholder="  YY/mm/dd/ H:i:s" style="width: 35%;height:34px;" name="end_time" class="layui-input1" id="test2">
                            </div>
                          </div> -->

                          <!-- 时间插件js代码 start -->
                          <script> 
                            layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //执行一个laydate实例
                              laydate.render({
                                elem: '#test1' //指定元素
                                ,type: 'datetime'
                              });
                            });
                             layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //执行一个laydate实例
                              laydate.render({
                                elem: '#test2' //指定元素
                                ,type: 'datetime'
                              });
                            });
                          </script>
                           <!-- 时间插件js代码 end -->
                          <div class="form-group">
                            <label class="col-sm-2 control-label">添加创意类型</label>
                            <div class="col-sm-10">
                              <select class="form-control con" onchange="id_con()" name="creative_material_mode">
                                <?php if(is_array($ideas_type) || $ideas_type instanceof \think\Collection || $ideas_type instanceof \think\Paginator): $i = 0; $__LIST__ = $ideas_type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $vo['id']; ?>"><?php echo $vo['ideas_type_name']; ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                              </select>
                            </div>
                            <!-- 图片/视频 -->
                            <div style="width: 80%;height: 300px;margin-left: 18.3%" >
                            <table style="" class="table-responsive table" id="tb">
                            	<tr>
                            		<td class="title_f">创意类型</td>
                            	</tr>
                            	<tr>
                            		<td style="width: 100px;">
                            			创意标题  
                            		</td>
                            		<td><input type="text" class="form-control" name="title_list"></td>
                            	</tr>
                            	<tr>
                            		<td>
                            			创意内容
                            		</td>
                            		<td><input type="file" name="file"></td>
                            	</tr>

                            </table>
                            </div>
						

                          </div>

							<script>
								function id_con(){
									var id = $('.con').val();
                  //console.log(id);
                    $.get("<?php echo url('Ajax/ideas_type'); ?>",{id:id},function(data){
                                        //alert('Ajax从服务器端返回来的值是：'+data);
                                        console.log(data);
                                        if(data!='error'){
                                        $('.title_f').html(data.ideas_type_name);
                                        }
                                     });
									
								}
							</script>
						<div class="form-group">
                            <label class="col-md-2 control-label" for="example-email" >来源</label>
                            <div class="col-md-10">
                              <input id="example-email" name="source" class="form-control" placeholder="" type="text">
                            </div>
                          </div>
                          
                       


                          <div class="form-group m-b-0" id="an" >
                           <input type="submit" class="layui-btn layui-btn-danger" onclick="history.go(-1)" value="返回" style="float: right;margin-right: 12px;background-color:#aaa">
                            <div class="col-sm-offset-3 col-sm-9" style="margin-left:16.5%;">
                              <input type="submit" class="btn btn-primary" name="goon" value="继续添加">
                              <input type="submit" class="btn btn-primary" name="yes" value="确认">

                            </div>
                        </div>
                          
                        </form>
                   </div>
                  </div>
              </div>
              <script>
                  function id_type(){ //获取二级行业
                    var id = $('#yiji').val();
                    //alert(y_id)
                    $.get("<?php echo url('Ajax/get_industry_second'); ?>",{id:id},function(data){
                                        //alert('Ajax从服务器端返回来的值是：'+data);
                                        //console.log(data);
                                        if(data!='error'){
                                          //console.log(data);
                                          $("#second_industry").empty();
                                          $("#third_industry").empty();
                                          for(i = 0; i < data.length; i++) {
                                            var id = data[i]['industry_id'];
                                            var name = data[i]['industry_name'];
                                                    
                                                    $('#second_industry').append("<option value="+id+">"+name+"</option>");
                                                    $('#second_industry').show();
                                            } 
                                        }
                                     });
                  }
                  function second_data(){ //获取三级行业
                    var id = $('#second_industry').val();
                     $.get("<?php echo url('Ajax/get_industry_third'); ?>",{id:id},function(data){
                                        //alert('Ajax从服务器端返回来的值是：'+data);
                                        //console.log(data);
                                        if(data!='error'){
                                          //console.log(data);
                                          $("#third_industry").empty();
                                          for(i = 0; i < data.length; i++) {
                                            var id = data[i]['industry_id'];
                                            var name = data[i]['industry_name'];
                                                    
                                                    $('#third_industry').append("<option value="+id+">"+name+"</option>");
                                                    $('#third_industry').show();
                                            } 
                                        }
                                     });
                  }
              </script>
             <!--End row-->

                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>