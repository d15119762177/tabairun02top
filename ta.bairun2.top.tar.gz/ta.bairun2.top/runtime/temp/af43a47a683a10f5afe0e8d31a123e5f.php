<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:73:"/www/wwwroot/ta.bairun2.top/public/../application/admin/view/plan/add.php";i:1574840680;s:17:"common/header.php";i:1574668111;s:15:"common/foot.php";i:1571793815;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title>Home</title>

    <!--Begin  Page Level  CSS -->
    <link href="/static/assets/plugins/morris-chart/morris.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"/>
     <!--End  Page Level  CSS -->
    <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
    <script type="text/javascript" src="jquery-2.1.1.min.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
    #tag{
      margin-top:0px;

    }
    #tag font{
      margin:0px 5px 0px 5px;
      display:inline-block;
      width:60px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: black;
      background-color: #eee;
      overflow: hidden;
    }
</style>
</head>
<script src="/static/layui/layui.js"></script>
<body class="sticky-header">


    <!--Start left side Menu-->
    <div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="/static/assets/images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="/static/assets/images/logo-icon.png" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list"><a href="<?php echo url('Index/index'); ?>"><i class="icon-layers"></i> <span>广告组</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Index/index'); ?>"> Buttons</a></li>
                        <li><a href="<?php echo url('Index/index'); ?>"> Panels</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="<?php echo url('Plan/index'); ?>"><i class="icon-grid"></i> <span>广告计划</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Plan/index'); ?>"> Basic Table</a></li>
                        <li><a href="<?php echo url('Plan/index'); ?>">Responsive Table</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>广告创意</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Inbox</a></li>
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Compose Mail</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>Excel批量上传</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Batch/index'); ?>"> 批量创建广告组</a></li>
                        <li><a href="<?php echo url('Batch/plan_up'); ?>"> 批量创建广告计划</a></li>
                        <li><a href="<?php echo url('Batch/ideas_up'); ?>"> 批量创建广告创意</a></li>
                    </ul>
                </li>
            </ul>
            <!--End sidebar nav-->

        </div>
    </div>
    <!--End left side menu-->
    
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <a class="toggle-btn"><i class="fa fa-bars"></i></a>

            <form class="searchform">
                <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
            </form>

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-tasks"></i>
                            <span class="badge">8</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                            <h5 class="title">You have 8 pending task</h5>
                            <ul class="dropdown-list">
                            <li class="notification-scroll-list notification-list ">
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa  fa-shopping-cart noti-primary"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">A new order has been placed.</h5>
                                        <p class="m-0">
                                            <small>29 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-check noti-success"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Databse backup is complete</h5>
                                        <p class="m-0">
                                            <small>12 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-user-plus noti-info"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New user registered</h5>
                                        <p class="m-0">
                                             <small>17 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                                <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-diamond noti-danger"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Database error.</h5>
                                        <p class="m-0">
                                             <small>11 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-cog noti-warning"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New settings</h5>
                                        <p class="m-0">
                                             <small>18 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                             </li>
                             <li class="last"> <a href="#">View all notifications</a> </li>
              </ul>
                        </div>
                    </li>
                    
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge">4</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                         <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
             <li class="message-list message-scroll-list">
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-8.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">15 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-7.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">10 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                         
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
            </li>
            <li class="last"> <a  href="#">All Messages</a> </li>
          </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="/static/assets/images/users/avatar-6.jpg" alt="" />
                            <?php echo \think\Request::instance()->cookie('advertiser_id'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                          <li> <a href="#"> <i class="fa fa-wrench"></i> <?php echo \think\Request::instance()->cookie('advertiser_id'); ?> </a> </li>
                          <!-- <li> <a href="#"> <i class="fa fa-user"></i> Profile </a> </li>
                          <li> <a href="#"> <i class="fa fa-info"></i> Help </a> </li> -->
                          <li> <a href="<?php echo url('index/exit'); ?>"> <i class="fa fa-lock"></i> Logout </a> </li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>
        <!-- header section end-->
        <!--body wrapper start-->
        <div class="wrapper">

        <!-- <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a> -->
   <!--Start row-->
             <div class="row">
                 <div class="col-md-12">
                   <div class="white-box">
                     <h2 class="header-title">创建广告计划</h2>
                       
                        <form class="form-horizontal" action="<?php echo url('doadd'); ?>" method="post">
                          <div class="form-group">
                            <label class="col-md-2 control-label">广告主ID</label>
                            <div class="col-md-10">
                              <input class="form-control" name="advertiser_id" value="<?php echo $advertiser_id; ?>" type="text" readonly="">
                            </div>
                          </div>


                          <div class="form-group">
                            <label class="col-sm-2 control-label">广告组</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="campaign_id">
                                 <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                  <option value="<?php echo $vo['campaign_id']; ?>"><?php echo $vo['campaign_name']; ?></option>
                                  <?php endforeach; endif; else: echo "" ;endif; ?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <label class="col-md-2 control-label" for="example-email">计划名称</label>
                            <div class="col-md-10">
                              <input id="example-email" name="name" class="form-control" placeholder="" type="text" required>
                            </div>
                          </div>

                            <div class="form-group">
                            <label class="col-sm-2 control-label">广告投放速度类型</label>
                            <div class="col-sm-10">
                              <select class="form-control dj" name="flow_control_mode"  id="" value="" >
                                <option selected value="FLOW_CONTROL_MODE_FAST">优先跑量（对应CPC的加速投放）</option>
                                <option  value="FLOW_CONTROL_MODE_SMOOTH">优先低成本（对应CPC的标准投放）</option>
                                <option  value="FLOW_CONTROL_MODE_BALANCE">均衡投放（新增字段）</option>
                               <!--  <option>2</option> -->
                              </select>
                            </div>
                          </div>  

                          <div class="form-group">
                            <label class="col-sm-2 control-label" >预算</label>
                            <div class="col-sm-10">
                             <select name="budget_mode" id="aab" value="" style="margin: 0px;padding: 0px;float: left;height: 34px;border-right: 0px;" onchange="sel()">
                            <option id="ys" value="BUDGET_MODE_INFINITE" selected>不限</option>
                            <option id="ys" value="BUDGET_MODE_DAY" selected>日预算</option>
                            <option id="zys" value="BUDGET_MODE_TOTAL">总预算</option>
                          </select>    
                          <input type="text" name="budget" required  placeholder=" 请输入预算，不少于100元，不超过9999999.99元
" autocomplete="off" class="y_cont" style="margin:0px;padding: 0px;float: left;height: 34px;width: 50%;">     
                            </div>
                          </div>
                          <script>
                            function sel(){
                              //alert($("#aab").val());
                               if($("#aab").val()=='BUDGET_MODE_TOTAL'){
                             // alert('aa')
                              $('.y_cont').attr('placeholder',' 请输入预算，不少于投放天数*100元，不超过9999999.99元');
                              $('.y_cont').attr('readonly',false);
                             }
                            if($("#aab").val()=='BUDGET_MODE_DAY'){
                              $('.y_cont').attr('placeholder',' 请输入预算，不少于100元，不超过9999999.99元');
                              $('.y_cont').attr('readonly',false);
                               }
                            if($("#aab").val()=='BUDGET_MODE_INFINITE'){
                              $('.y_cont').attr('readonly',true);
                              $('.y_cont').attr('placeholder','');
                               }
                            }


                            //removeAttr() 方法从被选元素中移除属性。
                          </script>

                          <div class="form-group">
                            <label class="col-md-2 control-label">投放时间</label>
                            <div class="col-md-10">
                               <input type="text" placeholder=" YY/mm/dd/ H:i:s" style="width: 35%;height:34px;margin-right: 0px;padding-right: 0px;" name="start_time" class="layui-input1" id="test1" required> &nbsp;&nbsp;-&nbsp;&nbsp;
                                <input type="text" placeholder="  YY/mm/dd/ H:i:s" style="width: 35%;height:34px;" name="end_time" class="layui-input1" id="test2" required>
                                 <input type="hidden"  style="width: 35%;height:34px;" name="schedule_type" class="layui-input1" value="SCHEDULE_START_END">

                            </div>
                          </div>

                          <!-- 时间插件js代码 start -->
                          <script> 
                            layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //执行一个laydate实例
                              laydate.render({
                                elem: '#test1' //指定元素
                                ,type: 'datetime'
                              });
                            });
                             layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //执行一个laydate实例
                              laydate.render({
                                elem: '#test2' //指定元素
                                ,type: 'datetime'
                              });
                            });
                          </script>
                           <!-- 时间插件js代码 end -->
                           


                            <div class="form-group">
                            <label class="col-sm-2 control-label">付费方式</label>
                            <div class="col-sm-10">
                              <select class="form-control dj" name="pricing"  id="path" value="" onchange="pa()">
                                <option selected value="PRICING_OCPM">按展示付费(OCPM)</option>
                                <option  value="PRICING_CPV">按转化付费(CPA)</option>
                               <!--  <option>2</option> -->
                              </select>
                            </div>
                          </div>  
                          
                          
                          <div class="form-group" id="zh" style="display: none;">
                            <label class="col-md-2 control-label">点击出价</label>
                            <div class="col-md-10">
                              <input class="form-control" name="bid" placeholder="请输入点击出价，不少于0.2元，不超过100元" type="text" style="width:40%;">
                            </div>
                          </div>

                          <div class="form-group" >
                            <label class="col-md-2 control-label">转化出价</label>
                            <div class="col-md-10">
                              <input class="form-control" name="cpa_bid" placeholder="请输入点击出价，不少于0.1元，不超过10000元" type="text" style="width:40%;" required>
                            </div>
                          </div>

                          <div class="form-group">
                            <label class="col-md-2 control-label" >投放范围</label>
                            <div class="col-md-10">
                              <input class="form-control" name="delivery_range1" placeholder="默认" type="text" style="width:6%;" readonly="" value="默认">
                              <input type="hidden" name="delivery_range" value="DEFAULT">
                            </div>
                          </div>


                          
                            <div class="form-group">
                            <label class="col-md-2 control-label">投放目标</label>
                            <div class="col-md-10">
                              <input style="height: 14px;width: 14px;line-height: 34px;" type="radio" name="target" value="zhl" title="" checked> 转化量&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <input style="height: 14px;width: 14px;line-height: 34px;" type="radio" name="target" value="djl" title="" disabled=""> 点击量&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <input style="height: 14px;width: 14px;line-height: 34px;" type="radio" name="target" value="zsl" title="" disabled=""> 展示量
                            </div>
                          </div>

                          <div class="form-group">
                            <label class="col-md-2 control-label">落地页链接</label>
                            <div class="col-md-10">
                              <input class="form-control" id="url" name="external_url" value="" type="text" onchange="geturl()" required>
                            </div>
                          </div>

                          <div class="form-group" style="display: none;" id="mb">
                            <label class="col-sm-2 control-label">转化目标</label>
                            <div class="col-sm-10">
                              <select class="form-control dj" name="convert_id"  id="zhmb" value="">
                                    
                              </select>
                            </div>
                          </div>  
                        
                        <!--   <div class="form-group">
                            <label class="col-md-2 control-label">设置文章</label>
                            <div class="col-md-10">
                              <textarea class="form-control" rows="5" name="title"></textarea>
                            </div>
                          </div> -->


                          <div class="form-group m-b-0" id="an" >
                           <input type="submit" class="layui-btn layui-btn-danger" onclick="history.go(-1)" value="返回" style="float: right;margin-right: 12px;background-color:#aaa">
                            <div class="col-sm-offset-3 col-sm-9" style="margin-left:16.5%;">
                              <input type="submit" class="btn btn-primary" name="goon" value="继续添加">
                              <input type="submit" class="btn btn-primary" name="next" value="下一步">
                            </div>
                        </div>
                          
                        </form>
                   </div>
                  </div>
              </div>

              <script type="text/javascript">
                function pa(){
                 // alert($('#path').val());
                  if($('#path').val() == 'PRICING_OCPM'){
                    $('#zh').attr('disabled',true);
                  $('#zh').hide();
                }
                  if($('#path').val() == 'PRICING_CPV'){
                  $('#zh').show();
                  $('#zh').attr('disabled',false);
                }
                }
             
                function geturl(){
                  var geturl = $('#url').val();
                  //alert(url);
                  //console.log(geturl);
                 // url = '1';
                
                $.post("<?php echo url('Plan/ajax_convert_id'); ?>", {geturl: geturl},
                        function(data){

                          if(data.msg=="数据为空或数据出错"){
                            alert('落地页链接错误');
                            $('#mb').hide();
                          }
                          
                       // alert(data); // John
                        console.log(data); //  2pm
                        for(i = 0; i < data.length; i++) {
                          var id = data[i]['convert_id'];
                        //  alert(id)
                          var name = data[i]['name'];
                                 
                                  $('#zhmb').append("<option value="+id+">"+name+"</option>");
                                  $('#mb').show();
                          } 

                        }, "json");
                }

              </script>
             <!--End row-->

                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>