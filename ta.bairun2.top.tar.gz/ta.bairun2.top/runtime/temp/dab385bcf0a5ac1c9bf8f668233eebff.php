<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"/www/wwwroot/ta.bairun2.top/public/../application/admin/view/ideas/edit.php";i:1572261472;s:17:"common/header.php";i:1574649679;s:15:"common/foot.php";i:1571793815;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title>Home</title>

    <!--Begin  Page Level  CSS -->
    <link href="/static/assets/plugins/morris-chart/morris.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"/>
     <!--End  Page Level  CSS -->
    <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
    #tag{
      margin-top:0px;

    }
    #tag font{
      margin:0px 5px 0px 5px;
      display:inline-block;
      width:60px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: black;
      background-color: #eee;
      overflow: hidden;
    }
</style>
</head>
<script src="/static/layui/layui.js"></script>
<body class="sticky-header">


    <!--Start left side Menu-->
    <div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="/static/assets/images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="/static/assets/images/logo-icon.png" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list"><a href="<?php echo url('Index/index'); ?>"><i class="icon-layers"></i> <span>广告组</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Index/index'); ?>"> Buttons</a></li>
                        <li><a href="<?php echo url('Index/index'); ?>"> Panels</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="<?php echo url('Plan/index'); ?>"><i class="icon-grid"></i> <span>广告计划</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Plan/index'); ?>"> Basic Table</a></li>
                        <li><a href="<?php echo url('Plan/index'); ?>">Responsive Table</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>广告创意</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Inbox</a></li>
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Compose Mail</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>Excel批量上传</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Batch/index'); ?>"> 批量创建广告组</a></li>
                        <li><a href="<?php echo url('Batch/plan_up'); ?>"> 批量创建广告计划</a></li>
                        <li><a href="<?php echo url('Batch/ideas_up'); ?>"> 批量创建广告创意</a></li>
                    </ul>
                </li>
            </ul>
            <!--End sidebar nav-->

        </div>
    </div>
    <!--End left side menu-->
    
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <a class="toggle-btn"><i class="fa fa-bars"></i></a>

            <form class="searchform">
                <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
            </form>

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-tasks"></i>
                            <span class="badge">8</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                            <h5 class="title">You have 8 pending task</h5>
                            <ul class="dropdown-list">
                            <li class="notification-scroll-list notification-list ">
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa  fa-shopping-cart noti-primary"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">A new order has been placed.</h5>
                                        <p class="m-0">
                                            <small>29 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-check noti-success"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Databse backup is complete</h5>
                                        <p class="m-0">
                                            <small>12 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-user-plus noti-info"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New user registered</h5>
                                        <p class="m-0">
                                             <small>17 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                                <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-diamond noti-danger"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Database error.</h5>
                                        <p class="m-0">
                                             <small>11 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-cog noti-warning"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New settings</h5>
                                        <p class="m-0">
                                             <small>18 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                             </li>
                             <li class="last"> <a href="#">View all notifications</a> </li>
              </ul>
                        </div>
                    </li>
                    
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge">4</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                         <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
             <li class="message-list message-scroll-list">
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-8.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">15 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-7.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">10 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                         
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
            </li>
            <li class="last"> <a  href="#">All Messages</a> </li>
          </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="/static/assets/images/users/avatar-6.jpg" alt="" />
                            <?php echo \think\Request::instance()->cookie('advertiser_id'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                          <li> <a href="#"> <i class="fa fa-wrench"></i> <?php echo \think\Request::instance()->cookie('advertiser_id'); ?> </a> </li>
                          <!-- <li> <a href="#"> <i class="fa fa-user"></i> Profile </a> </li>
                          <li> <a href="#"> <i class="fa fa-info"></i> Help </a> </li> -->
                          <li> <a href="<?php echo url('index/exit'); ?>"> <i class="fa fa-lock"></i> Logout </a> </li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>
        <!-- header section end-->
        <!--body wrapper start-->
        <div class="wrapper">

        <!-- <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a> -->
<!--Start row-->
             <div class="row">
                 <div class="col-md-12">
                   <div class="white-box">
                     <h2 class="header-title">������洴��</h2>
                       
                        <form action="<?php echo url('Ideas/update'); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                          <div class="form-group">
                            <label class="col-md-2 control-label">�����ID</label>
                            <div class="col-md-10">
                              <input class="form-control" name="advertiser_id" value="1111111111" type="text" readonly="">
                            </div>
                          </div>


                          <div class="form-group">
                            <label class="col-sm-2 control-label">���ƻ�</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="ad_id">
                                <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $vo['id']; ?>" <?php if($data['ad_id'] == $vo['id']): ?> selected <?php endif; ?>><?php echo $vo['name']; ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                              </select>
                            </div>
                          </div>
                          
                        <!--   <div class="form-group">
                            <label class="col-md-2 control-label" for="example-email">Ͷ��λ��</label>
                            <div class="col-md-10">
                              <input id="example-email" name="inventory_type" class="form-control" placeholder="" type="text">
                            </div>
                          </div> -->




                          <div class="form-group">
                            <label class="col-sm-2 control-label" >Ͷ��λ��</label>
                            <div class="col-sm-10">
                             <select name="inventory_type" id="tfwz" onchange="tf()" value="" style="margin: 0px;padding: 0px;float: left;height: 34px;">
                            <option id="ys" value="1"  <?php if($data['inventory_type'] == 1): ?> selected <?php endif; ?>>��ѡ���λ</option>
                            <option id="zys" value="2" <?php if($data['inventory_type'] == 2): ?> selected <?php endif; ?>>��ý��ָ��λ��</option>
                            <option id="zys" value="3" <?php if($data['inventory_type'] == 3): ?> selected <?php endif; ?>>������ָ��λ��</option>
                          </select></div>
                          <div class="app" style="margin-left:18.5%;margin-top: 2.5%;display:none;">
                          	<table>
                          		<th>APP����</th>
                          		<tr>
                          			<td><input type="checkbox" name="app_name[0]" value="jrtt" title="����ͷ��" lay-skin="primary" checked>����ͷ��</td>
								</tr><tr>
                          			<td><input type="checkbox" name="app_name[1]" value="xgsp" title="������Ƶ" lay-skin="primary"> ������Ƶ</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[2]" value="hssp" title="��ɽС��Ƶ" lay-skin="primary" > ��ɽС��Ƶ</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[3]" value="dy" title="����" lay-skin="primary" > ����</td>
								</tr><tr>
									<td><input type="checkbox" name="app_name[4]" value="csj" title="��ɽ��" lay-skin="primary" > ��ɽ��</td>
                          		</tr>
                          	</table>
                            </div>
                          <div class="changjing" style="margin-left:18.5%;margin-top: 2.5%;display:none;">
                          	<table>
                          		<th>λ��ѡ��</th>
                          		<tr>
                          			<td><input type="checkbox" name="place[0]" title="����ʽ������Ƶ����" lay-skin="primary" checked>����ʽ������Ƶ����</td>
								</tr><tr>
                          			<td><input type="checkbox" name="place[1]" title="��Ϣ������" lay-skin="primary"> ��Ϣ������</td>
								</tr><tr>
									<td><input type="checkbox" name="place[2]" title="��Ƶ������β֡����" lay-skin="primary" > ��Ƶ������β֡����</td>
								</tr>
                          	</table>
                            </div>

                        </div>


							<script>
                            // function sel(){
                            //   //alert($("#aab").val());
                            //    if($("#aab").val()=='0571'){
                            //  // alert('aa')
                            //   $('.y_cont').attr('placeholder',' ������Ԥ�㣬������200Ԫ��������9999999.99Ԫ');
                            //  }
                            // if($("#aab").val()=='010'){
                            //   $('.y_cont').attr('placeholder',' ������Ԥ�㣬������100Ԫ��������9999999.99Ԫ');
                            //    }
                            // }
                            //removeAttr() �����ӱ�ѡԪ�����Ƴ����ԡ�
                            function tf(){
                            	if($('#tfwz').val()=='2'){
                            		$('.changjing').hide();
                            		$('.app').show();
                            	}
                            	if($('#tfwz').val()=='3'){
                            		$('.app').hide();
                            		$('.changjing').show();
                            	}
                            	if($('#tfwz').val()=='1'){
                            		$('.app').hide();
                            		$('.changjing').hide();
                            	}
                            }
                          </script>



                            <div class="form-group">
                            <label class="col-sm-2 control-label">�������</label>
                            <div class="col-sm-10">
                              <select class="form-control" name="third_industry_id">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                              </select>
                            </div>
                          </div>

                          <div class="form-group">
                            <label class="col-sm-2 control-label" >�����ǩ</label>
                            <div class="col-sm-10">
                         <!-- <input type="submit" style="margin: 0px;padding: 0px;float: left;height: 34px;border-right: 0px;width: 60px;">  -->
                         <a href="javascript:;" style="margin: 0px;padding: 0px;float: left;height: 34px;width: 80px;background-color: rgb(95,184,150);text-align: center;line-height: 34px;color: white;border-right: 0px;border-color: rgb(169,169,169);" onclick="add_type()">���ӱ�ǩ</a>
                          <input class="bq_type" type="text" name="title"   placeholder=" ���20����ǩ��ÿ������10��
" autocomplete="off" class="y_cont" style="margin:0px;padding: 0px;float: left;height: 34px;width: 50%;" >     
                            </div>

                            <div id="tag" style="margin-left:18.5%;margin-top: 3%;width: 40%;" value="��ǩ" name="tag">
                            <p>��ѡ��ǩ��</p>
                            <!-- <table style="" class="table table-hover" id="tb">
                            	<tr>
                            		<td>��ѡ��ǩ</td>
                            	</tr> -->
                            
                            <!-- </table> -->
                            <?php if(is_array($tag_data) || $tag_data instanceof \think\Collection || $tag_data instanceof \think\Paginator): $i = 0; $__LIST__ = $tag_data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <font name="bq1" value="1111111111"><?php echo $vo['name']; ?><input type="hidden" name="ad_keywords[<?php echo $vo['id']; ?>]" value="<?php echo $vo['id']; ?>"></font>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                          </div>
                          <script>
                          function add_type(){
                            	 var name = $('.bq_type').val();
                                $.get("<?php echo url('Ajax/index'); ?>",{name:name},function(data){
                                        //alert('Ajax�ӷ������˷�������ֵ�ǣ�'+data);
                                        console.log(data);
                                        if(data == 'success'){
                                         $('#tag').append(`<font >`+ name +`</font>`);
                                        }
                                     });
                            	var a = $("#tb").find("tr").length;
                            	console.log(a);
                             }

                          </script>

                        <!--   <div class="form-group">
                            <label class="col-md-2 control-label">Ͷ��ʱ��</label>
                            <div class="col-md-10">
                               <input type="text" placeholder=" YY/mm/dd/ H:i:s" style="width: 35%;height:34px;margin-right: 0px;padding-right: 0px;" name="stat_time" class="layui-input1" id="test1"> &nbsp;&nbsp;-&nbsp;&nbsp;
                                <input type="text" placeholder="  YY/mm/dd/ H:i:s" style="width: 35%;height:34px;" name="end_time" class="layui-input1" id="test2">
                            </div>
                          </div> -->

                          <!-- ʱ����js���� start -->
                          <script> 
                            layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //ִ��һ��laydateʵ��
                              laydate.render({
                                elem: '#test1' //ָ��Ԫ��
                                ,type: 'datetime'
                              });
                            });
                             layui.use('laydate', function(){
                              var laydate = layui.laydate;
                              
                              //ִ��һ��laydateʵ��
                              laydate.render({
                                elem: '#test2' //ָ��Ԫ��
                                ,type: 'datetime'
                              });
                            });
                          </script>
                           <!-- ʱ����js���� end -->
                          <div class="form-group">
                            <label class="col-sm-2 control-label">���Ӵ�������</label>
                            <div class="col-sm-10">
                              <select class="form-control con" onchange="id_con()" name="creative_material_mode">
                                <option value="�����ͼ">�����ͼ</option>
                                <option value="��ͼ">��ͼ</option>
                                <option value="Сͼ">Сͼ</option>
                                <option value="��ͼ��ͼ">��ͼ��ͼ</option>
                                <option value="�����Ƶ">�����Ƶ</option>
                                <option value="������Ƶ">������Ƶ</option>
                              </select>
                            </div>
                            <!-- ͼƬ/��Ƶ -->
                            <div style="width: 80%;height: 300px;margin-left: 18.3%" >
                            <table style="" class="table-responsive table" id="tb">
                            	<tr>
                            		<td class="title_f">�����ͼ</td>
                            	</tr>
                            	<tr>
                            		<td style="width: 100px;">
                            			�������  
                            		</td>
                            		<td><input type="text" class="form-control" name="title_list"></td>
                            	</tr>
                            	<tr>
                            		<td>
                            			��������
                            		</td>
                            		<td><input type="file" name="file"></td>
                            	</tr>

                            </table>
                            </div>
						

                          </div>

							<script>
								function id_con(){
									var name = $('.con').val();
									$('.title_f').html(name);
								}
							</script>
						<div class="form-group">
                            <label class="col-md-2 control-label" for="example-email" >��Դ</label>
                            <div class="col-md-10">
                              <input id="example-email" name="source" class="form-control" placeholder="" type="text">
                            </div>
                          </div>
                          
                       


                          <div class="form-group m-b-0" id="an" >
                           <input type="submit" class="layui-btn layui-btn-danger" onclick="history.go(-1)" value="����" style="float: right;margin-right: 12px;background-color:#aaa">
                            <div class="col-sm-offset-3 col-sm-9" style="margin-left:16.5%;">
                              <input type="submit" class="btn btn-primary" name="goon" value="��������">
                              <input type="submit" class="btn btn-primary" name="yes" value="ȷ��">

                            </div>
                        </div>
                          
                        </form>
                   </div>
                  </div>
              </div>
             <!--End row-->

                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>