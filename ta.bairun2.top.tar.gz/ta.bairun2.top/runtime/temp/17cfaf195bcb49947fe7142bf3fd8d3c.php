<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"/www/wwwroot/ta.bairun2.top/public/../application/admin/view/index/edit.php";i:1574324150;s:17:"common/header.php";i:1572491912;s:15:"common/foot.php";i:1571793815;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title>Home</title>

    <!--Begin  Page Level  CSS -->
    <link href="/static/assets/plugins/morris-chart/morris.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"/>
     <!--End  Page Level  CSS -->
    <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
    #tag{
      margin-top:0px;

    }
    #tag font{
      margin:0px 5px 0px 5px;
      display:inline-block;
      width:60px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: black;
      background-color: #eee;
      overflow: hidden;
    }
</style>
</head>
<script src="/static/layui/layui.js"></script>
<body class="sticky-header">


    <!--Start left side Menu-->
    <div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="/static/assets/images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="/static/assets/images/logo-icon.png" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list"><a href="<?php echo url('Index/index'); ?>"><i class="icon-layers"></i> <span>广告组</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Index/index'); ?>"> Buttons</a></li>
                        <li><a href="<?php echo url('Index/index'); ?>"> Panels</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="<?php echo url('Plan/index'); ?>"><i class="icon-grid"></i> <span>广告计划</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Plan/index'); ?>"> Basic Table</a></li>
                        <li><a href="<?php echo url('Plan/index'); ?>">Responsive Table</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>广告创意</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Inbox</a></li>
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Compose Mail</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>Excel批量上传</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Batch/index'); ?>"> 批量创建广告组</a></li>
                        <li><a href="<?php echo url('Batch/plan_up'); ?>"> 批量创建广告计划</a></li>
                        <li><a href="<?php echo url('Batch/ideas_up'); ?>"> 批量创建广告创意</a></li>
                    </ul>
                </li>
            </ul>
            <!--End sidebar nav-->

        </div>
    </div>
    <!--End left side menu-->
    
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <a class="toggle-btn"><i class="fa fa-bars"></i></a>

            <form class="searchform">
                <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
            </form>

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-tasks"></i>
                            <span class="badge">8</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                            <h5 class="title">You have 8 pending task</h5>
                            <ul class="dropdown-list">
                            <li class="notification-scroll-list notification-list ">
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa  fa-shopping-cart noti-primary"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">A new order has been placed.</h5>
                                        <p class="m-0">
                                            <small>29 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-check noti-success"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Databse backup is complete</h5>
                                        <p class="m-0">
                                            <small>12 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-user-plus noti-info"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New user registered</h5>
                                        <p class="m-0">
                                             <small>17 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                                <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-diamond noti-danger"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Database error.</h5>
                                        <p class="m-0">
                                             <small>11 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-cog noti-warning"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New settings</h5>
                                        <p class="m-0">
                                             <small>18 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                             </li>
                             <li class="last"> <a href="#">View all notifications</a> </li>
              </ul>
                        </div>
                    </li>
                    
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge">4</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                         <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
             <li class="message-list message-scroll-list">
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-8.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">15 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-7.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">10 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                         
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
            </li>
            <li class="last"> <a  href="#">All Messages</a> </li>
          </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="/static/assets/images/users/avatar-6.jpg" alt="" />
                            John Doe
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                          <li> <a href="#"> <i class="fa fa-wrench"></i> Settings </a> </li>
                          <li> <a href="#"> <i class="fa fa-user"></i> Profile </a> </li>
                          <li> <a href="#"> <i class="fa fa-info"></i> Help </a> </li>
                          <li> <a href="#"> <i class="fa fa-lock"></i> Logout </a> </li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>
        <!-- header section end-->
        <!--body wrapper start-->
        <div class="wrapper">

        <!-- <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a> -->
 
<!--Start row-->
             <div class="row">
                 <div class="col-md-12">
                   <div class="white-box">
                     <h2 class="header-title">Select Fields</h2>
                       
                        <form action="<?php echo url('update'); ?>" class="form-horizontal">
                          <div class="form-group">
                            <label class="col-md-2 control-label">广告主ID</label>
                            <div class="col-md-10">
                              <input class="form-control" name="advertiser_id" value="<?php echo $data['advertiser_id']; ?>" type="text" readonly="">
                              <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                            </div>
                          </div>
                          
                        
	                     <div class="form-group">
	                            <label class="col-sm-2 control-label">推广目的</label>
	                            <div class="col-sm-10">
	                              <select class="form-control" name="landing_type">
	                                <option value="1" <?php if($data['landing_type'] == 1): ?> selected <?php endif; ?>>1--应用推广</option>
	                                <option value="2" <?php if($data['landing_type'] == 2): ?> selected <?php endif; ?>>2--销售线索收集</option>
	                                <option value="3" <?php if($data['landing_type'] == 3): ?> selected <?php endif; ?>>3--抖音号推广</option>
	                                <option value="4" <?php if($data['landing_type'] == 4): ?> selected <?php endif; ?>>4--门店推广</option>
	                                <option value="5" <?php if($data['landing_type'] == 5): ?> selected <?php endif; ?>>5--产品目录推广</option>
	                                <option value="6" <?php if($data['landing_type'] == 6): ?> selected <?php endif; ?>>6--电商店铺推广</option>
	                                <option value="7" <?php if($data['landing_type'] == 7): ?> selected <?php endif; ?>>7--头条文章推广</option>
	                              </select>
	                            </div>
	                          </div>
                          
                          <!-- <div class="form-group">
                            <label class="col-md-2 control-label">Disabled</label>
                            <div class="col-md-10">
                              <input class="form-control" disabled="" value="Disabled value" type="text">
                            </div>
                          </div> -->
                            
                          <div class="form-group">
                            <label class="col-sm-2 control-label">广告组名称</label>
                            <div class="col-sm-10">
                              <input class="form-control" name="campaign_name" placeholder="Helping text" value="<?php echo $data['campaign_name']; ?>" type="text">
                              <input type="hidden" name="modify_time" value="<?php echo $data['modify_time']; ?>">
                              <input type="hidden" name="campaign_id" value="<?php echo $data['campaign_id']; ?>">
                              <input type="hidden" name="budget_mode" value="<?php echo $data['budget_mode']; ?>">
                              <span class="help-block"></span> </div>
                          </div>
                          
                           <div class="form-group">
                            <label class="col-md-2 control-label">广告预算</label>
                            <div class="col-md-10">
                            	<div class="layui-btn-group">
								  <button type="button" class="layui-btn" name="bx" value="bx" onclick="st()">不限</button>
								  <button type="button" class="layui-btn" id="zdys" name="zdys" value="" onclick="yy()">指定预算</button>
								</div>
 								<input class="form-control ys" name="budget" value="<?php echo $data['budget']; ?>" style="display: none;margin-top: 5px;" placeholder="请输入广告组预算，不低于1000.00元，不超过9999999.99元" type="text" >
                             
                            </div> 
                            <input class="form-control" value="1" name="bx" id="hid" type="hidden" >
                          </div>
                          
                          <div class="form-group m-b-0" id="an" >
                            <div class="col-sm-offset-3 col-sm-9" style="margin-left:16.5%;">
                            	<input type="submit" class="btn btn-primary" name="goon" value="修改">
                            	<!-- <div class="layui-btn-group">
								  <button href="javascript:;" type="button" class="btn btn-primary" name="next" onclick="goon()">下一步</button>
								</div> -->
                              <!-- <button href="javascript:;" class="btn btn-primary" style="background-color: rgb(0,150,136);" onclick="goon()">继续添加</button> -->
                            </div>
                        </div>
                        </form>
                   </div>
                  </div>
              </div>
             <!--End row-->

             <script>
             	function yy(){
             		$('.ys').show();
             	}
             	function st(){
             		$('.ys').hide();
             	}
             	function goon(){
					window.location.href=''             		
             	}
             </script>

                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>