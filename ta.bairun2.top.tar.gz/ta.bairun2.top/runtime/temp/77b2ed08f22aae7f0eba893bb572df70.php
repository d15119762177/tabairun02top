<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"/www/wwwroot/ta.bairun2.top/public/../application/admin/view/plan/index.php";i:1577064667;s:17:"common/header.php";i:1577150211;s:15:"common/foot.php";i:1571793815;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="stylesheet" href="/static/layui/css/layui.css">
  <link rel="stylesheet" href="/static/css/bootstrap.min.css">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title>Home</title>

    <!--Begin  Page Level  CSS -->
    <link href="/static/assets/plugins/morris-chart/morris.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"/>
     <!--End  Page Level  CSS -->
    <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
   <!--  <script type="text/javascript" src="/static/assets/css/jquery-3.3.1.min.js"></script> -->
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->
<style>
    #tag{
      margin-top:0px;

    }
    #tag font{
      margin:0px 5px 0px 5px;
      display:inline-block;
      width:60px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: black;
      background-color: #eee;
      overflow: hidden;
    }
</style>
</head>
<script src="/static/layui/layui.js"></script>
<body class="sticky-header left-side-collapsed">


    <!--Start left side Menu-->
    <div class="left-side sticky-left-side">

        <!--logo-->
        <div class="logo">
            <a href="index.html"><img src="/static/assets/images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.html"><img src="/static/assets/images/logo-icon.png" alt=""></a>
        </div>
        <!--logo-->

        <div class="left-side-inner">
            <!--Sidebar nav-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="menu-list"><a href="<?php echo url('Index/index'); ?>"><i class="icon-layers"></i> <span>广告组</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Index/index'); ?>"> Buttons</a></li>
                        <li><a href="<?php echo url('Index/index'); ?>"> Panels</a></li>
                    </ul>
                </li>
                
                <li class="menu-list"><a href="<?php echo url('Plan/index'); ?>"><i class="icon-grid"></i> <span>广告计划</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Plan/index'); ?>"> Basic Table</a></li>
                        <li><a href="<?php echo url('Plan/index'); ?>">Responsive Table</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>广告创意</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Inbox</a></li>
                        <li><a href="<?php echo url('Ideas/index'); ?>"> Compose Mail</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href="<?php echo url('Ideas/index'); ?>"><i class="icon-envelope-open"></i> <span>Excel批量上传</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="<?php echo url('Batch/index'); ?>"> 批量创建广告组</a></li>
                        <li><a href="<?php echo url('Batch/plan_up'); ?>"> 批量创建广告计划</a></li>
                        <li><a href="<?php echo url('Batch/ideas_up'); ?>"> 批量创建广告创意</a></li>
                    </ul>
                </li>
            </ul>
            <!--End sidebar nav-->

        </div>
    </div>
    <!--End left side menu-->
    
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <a class="toggle-btn"><i class="fa fa-bars"></i></a>

            <form class="searchform">
                <input type="text" class="form-control" name="keyword" placeholder="Search here..." />
            </form>

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-tasks"></i>
                            <span class="badge">8</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                            <h5 class="title">You have 8 pending task</h5>
                            <ul class="dropdown-list">
                            <li class="notification-scroll-list notification-list ">
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa  fa-shopping-cart noti-primary"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">A new order has been placed.</h5>
                                        <p class="m-0">
                                            <small>29 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-check noti-success"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Databse backup is complete</h5>
                                        <p class="m-0">
                                            <small>12 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-user-plus noti-info"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New user registered</h5>
                                        <p class="m-0">
                                             <small>17 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                                <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-diamond noti-danger"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">Database error.</h5>
                                        <p class="m-0">
                                             <small>11 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                    
                               <!-- list item-->
                               <a href="javascript:void(0);" class="list-group-item">
                                  <div class="media">
                                     <div class="pull-left p-r-10">
                                        <em class="fa fa-cog noti-warning"></em>
                                     </div>
                                     <div class="media-body">
                                        <h5 class="media-heading">New settings</h5>
                                        <p class="m-0">
                                             <small>18 min ago</small>
                                        </p>
                                     </div>
                                  </div>
                               </a>
                             </li>
                             <li class="last"> <a href="#">View all notifications</a> </li>
              </ul>
                        </div>
                    </li>
                    
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle info-number" data-toggle="dropdown">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge">4</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-head pull-right">
                         <h5 class="title">Notifications</h5>
                        <ul class="dropdown-list normal-list">
             <li class="message-list message-scroll-list">
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-8.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">15 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-7.jpg" class="img-circle" alt="img"></span>
                              <span class="subject">John Doe</span>
                              <span class="message"> New tasks needs to be done</span>
                               <span class="time">10 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                         
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                        
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
                          
                          <a href="#">
                              <span class="photo"> <img src="/static/assets/images/users/avatar-6.jpg" class="img-circle" alt="img"></span>
                               <span class="subject">John Doe</span>
                               <span class="message"> New tasks needs to be done</span>
                              <span class="time">20 minutes ago</span>
                          </a>
            </li>
            <li class="last"> <a  href="#">All Messages</a> </li>
          </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="/static/assets/images/users/avatar-6.jpg" alt="" />
                            <?php echo \think\Request::instance()->cookie('advertiser_id'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                          <li> <a href="#"> <i class="fa fa-wrench"></i> <?php echo \think\Request::instance()->cookie('advertiser_id'); ?> </a> </li>
                          <!-- <li> <a href="#"> <i class="fa fa-user"></i> Profile </a> </li>
                          <li> <a href="#"> <i class="fa fa-info"></i> Help </a> </li> -->
                          <li> <a href="<?php echo url('index/exit'); ?>"> <i class="fa fa-lock"></i> Logout </a> </li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>
        <!-- header section end-->
        <!--body wrapper start-->
        <div class="wrapper">

        <!-- <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a> -->

        <a href="<?php echo url('Index/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告组</a>
        <a href="<?php echo url('Plan/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告计划</a>
        <a href="<?php echo url('Ideas/add'); ?>" class="layui-btn" style="margin-left:15px;">创建广告创意</a>
				
                  <!-- Start responsive Table-->
                <div class="col-md-12">

                 <div class="white-box"> <form action="">
				<input type="text" name="title" required lay-verify="required" placeholder="请输入标题" autocomplete="off" class="layui-input" style="width: 30%;">
				<!-- <input type="button" value="广告组搜索" class="layui-btn layui-btn-primary" style=""> -->
				</form><br>
                    <h2 class="header-title">广告计划</h2>
                     <div class="table-responsive">
                         <table class="table table-bordered layui-form">
                          <form class="" action="">
                          <thead>
                            <tr>
                              <th style="width:100px;"></th>
                              <th>ID</th>
                              <th>广告计划名称</th>
                              <th>广告组名称</th>
                              <th>计划操作状态</th>
                              <th>计划状态</th>
                              <th>审核不通过原因</th>
                              <th>投放时间段</th>
                              <th>预算</th>
                              <th>付费方式</th>
                              <th>点击出价</th>
                              <th>转化出价</th>
                              <th>投放范围</th>
                              <th>落地页链接</th>
                              <th>操作</th>
                            </tr>
                          </thead>
                          <tbody>
                            
                            <?php if(empty($data) != true): if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <tr>
                              <td style=""  >
                               <!-- <input type="checkbox" name="zzz" lay-skin="switch" lay-text="开启|关闭"> -->
                                <input type="checkbox" <?php if($vo['opt_status'] == 'AD_STATUS_ENABLE'): ?> checked <?php endif; ?> name="anniu" lay-skin="switch" lay-text="开启|关闭"  lay-filter="filter" value="<?php echo $vo['pid']; ?>">
                                <!-- <input type="checkbox" onchange="du()"> -->
                              </td>
                              <td ><?php echo $vo['pid']; ?></td>
                              <td title="<?php echo $vo['name']; ?>" onclick="look(res=`<?php echo $vo['name']; ?>`)"><?php echo $vo['name']; ?></td>
                              <td title="<?php echo $vo['advertising_name']; ?>" onclick="look(res=`<?php echo $vo['advertising_name']; ?>`)"><?php echo $vo['advertising_name']; ?></td>
                              <?php if($vo['opt_status'] == 'AD_STATUS_ENABLE'): ?>
                              <td >开启</td>
                              <?php endif; if($vo['opt_status'] == 'AD_STATUS_DISABLE' || $vo['opt_status'] == ''): ?>
                              <td >暂停</td>
                              <?php endif; ?>
                              <td><?php echo $vo['status']; ?></td>
                              <td title="<?php echo $vo['audit_reject_reason']; ?>" onclick="look(res=`<?php echo $vo['audit_reject_reason']; ?>`)" class="reason"><?php echo $vo['audit_reject_reason']; ?></td>
                              <td title="<?php echo $vo['start_time']; ?> - <?php echo $vo['end_time']; ?>"><?php echo $vo['start_time']; ?> - <?php echo $vo['end_time']; ?></td>
                              <td ><?php echo $vo['budget']; ?></td>
                              <td ><?php echo $vo['pricing']; ?></td>
                               <td ><?php echo $vo['bid']; ?></td>
                               <td ><?php echo $vo['cpa_bid']; ?></td>
                              <td ><?php echo $vo['delivery_range']; ?></td>
                              <td title="<?php echo $vo['external_url']; ?>" onclick="look(res=`<?php echo $vo['external_url']; ?>`)" class="url"><?php echo $vo['external_url']; ?></td>
                              <td>
                                <a href="<?php echo url('Plan/edit',['campaign_id'=>$vo['campaign_id'],'pid'=>$vo['pid']]); ?>">修改</a>
                                <a href="javascript:;" onclick="del()">删除</a>
                                <a href="javascript:;" onclick="del()">批量删除</a>
                              </td>
                            </tr>
                             <div style="
                             width:300px;height: 200px;
                             background-color: rgb(255,254,255);
                             position: fixed;
                             top: 30%;left: 42%;
                             z-index: 999;
                             border-radius: 20px;
                             display:none;
                             " class="tk">
                             <p style="color: black;text-align: center;font-size: 30px;margin-top:16%; ">确认删除吗？</p>
                             <a href="javascript:;" class="btn btn-success" style="float: left;margin-top: 15%;margin-left: 23%" onclick="ex()">按错了</a>
                             <a href="<?php echo url('Plan/del',['id'=>$vo['id']]); ?>" class="btn btn-danger" style="float: right;margin-top: 15%;margin-right: 27%">确定</a>
                             </div>
                          <?php endforeach; endif; else: echo "" ;endif; endif; ?>
                           </tbody>
                          </form>
                        </table>
                       <!-- 页码 start -->
                        <div style="height: 35px;background-color:white;width: 100%;line-height: 35px;font-size: 15px;">
                            <form action="<?php echo url('Plan/index'); ?>"> <span>第<b class="page"><?php echo $page; ?></b>页</span>&nbsp;&nbsp;&nbsp;
                            <a href="<?php echo url('Plan/index',['page_num'=>$page,'page'=>'last']); ?>" onclick="last_page()">上一页</a>&nbsp;&nbsp;&nbsp;
                            <a href="<?php echo url('Plan/index',['page_num'=>$page,'page'=>'next','count'=>$count]); ?>" onclick="next_page()">下一页</a>&nbsp;&nbsp;
                           跳转
                           &nbsp;<input type="text" style="height: 20px;width: 40px;" name="input_page">&nbsp;页
                           <span style="float: right;">统计一共 <b><?php echo $sum; ?></b> 条数据</span>
                         </form>
                        </div>
                        <!--  页码 end -->
                     </div>
                      
                              <div class="hei" style="position: fixed;top: 0px;left: 0px;bottom: 0px;right: 0px;width: 100%;height: 100%;background-color: black;opacity: 0.5;display:none;"></div>
                 </div>
                  
                 </div>
                 <script>
                  function del(){
                                //alert('确定删除吗？');
                                $('.tk').show();
                                $('.hei').show();
                              }
                  function ex(){
                              $('.tk').hide();
                              $('.hei').hide();
                  }
                  function look(title){
                    var a = title;
                    // var data = $(a).html();
                    alert(a);

                  }
         </script>
                 </div>
               <!-- End responsive Table-->        
          
 
<!-- <script>
//Demo
layui.use('form', function(){
  var form = layui.form;
  
  //监听提交
  form.on('submit(formDemo)', function(data){
    layer.msg(JSON.stringify(data.field));
    return false;
  });
});
</script>
			   <script>
            function dd(){
              var a = $('.kg').val();
              console.log(a);
              alert(a);
            }
         </script> -->

         <script>
//Demo
layui.use('form', function(){
  var form = layui.form;
  
form.on('switch(filter)', function(data){
 // alert('aaa');
  console.log(data);
  var status = data.elem.checked;
  var advertiser_id = $('#adv').val();
  var pid = data.value;
  pid = parseInt(pid);
  if(status){
    
    //var campaign_ids = array(data.value);
    alert('已开启');
    $.ajax({
        type: "POST",
        url: "<?php echo url('Ajax/update_plan_status'); ?>",
        data: {
          "advertiser_id": advertiser_id,
          "pid": [pid],
          "opt_status":'enable'
        },
        dataType: "JSON",
        success: function(result) {
          console.log(result);
          //alert('已开启');
        }
      });

    
  }else{
    $.ajax({
        type: "POST",
        url: "<?php echo url('Ajax/update_plan_status'); ?>",
        data: {
          "advertiser_id": advertiser_id,
          "pid": [pid],
          "opt_status":'disable',
        },
        dataType: "JSON",
        success: function(res) {
          console.log(res);
          var data = JSON.parse(res);

          console.log(data);
        //  alert(res.code);
        //  alert('开启');
        }
      });
    alert('已暂停')
  }
});
  //监听提交
  form.on('submit(formDemo)', function(data){
    layer.msg(JSON.stringify(data.field));
    return false;
  });
});


</script>
		


                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>



   

