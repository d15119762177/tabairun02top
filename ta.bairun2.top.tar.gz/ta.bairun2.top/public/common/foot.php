
                </div>
        <!-- End Wrapper-->
        <!--Start  Footer -->
        <footer class="footer-main">Copyright &copy; 2018.Company name All rights reserved.<a target="_blank" href="http://sc.chinaz.com/moban/">&#x7F51;&#x9875;&#x6A21;&#x677F;</a></footer>  
         <!--End footer -->

       </div>
      <!--End main content -->
    


    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <script src="/static/assets/plugins/moment/moment.js"></script>
    <script  src="/static/assets/js/jquery.slimscroll.js "></script>
    <script src="/static/assets/js/jquery.nicescroll.js"></script>
    <script src="/static/assets/js/functions.js"></script>
    <!-- End core plugin -->
    
    <!--Begin Page Level Plugin-->
  <script src="/static/assets/plugins/morris-chart/morris.js"></script>
    <script src="/static/assets/plugins/morris-chart/raphael-min.js"></script>
    <script src="/static/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="/static/assets/pages/dashboard.js"></script>
    <!--End Page Level Plugin-->
   

</body>

</html>