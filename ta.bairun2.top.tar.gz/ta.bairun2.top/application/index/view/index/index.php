<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="/static/assets/images/favicon.png" type="image/png">
  <title></title>
   <link href="/static/assets/css/icons.css" rel="stylesheet">
    <link href="/static/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/css/responsive.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="js/html5shiv.min.js"></script>
          <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body class="sticky-header" style="background:url(./g.gif) no-repeat center 0;background-size: 100%;">

 
 <!--Start login Section-->
  <section class="login-section">
       <div class="container">
           <div class="row">
               <div class="login-wrapper">
                   <div class="login-inner" style="margin-top:224px;background:url(./g2.gif) no-repeat center 0;box-shadow: 5px 5px 5px black;">
                       
                       <div class="logo">
                         <img src="/static/assets/images/logo-dark.png"  alt="logo"/>
                       </div>
                   		
                   		<h2 class="header-title text-center" style="font-size: 20px;">广告主授权</h2>
                        <p style="text-align: center;background-color: rgb(58,136,255);border-radius: 5px;width: 100%;height: 40px;font-size: 20px;line-height: 40px;"><a 
                          href="https://ad.oceanengine.com/openapi/audit/oauth.html?app_id=1651141812090893&state=your_custom_params&scope=%5B130%2C3%2C5%2C12%2C2%2C110%2C4%5D&redirect_uri=http%3A%2F%2Fta.bairun2.top%2Findex.php%2Findex%2Fapi" 
                          style="text-align: center;color: white;">点击去授权</a></p>
                
                       
                        <div class="copy-text"> 
                         <p class="m-0">2019 &copy;  admin</p>
                        </div>
                    
                   </div>
               </div>
               
           </div>
       </div>
  </section>
 <!--End login Section-->




    <!--Begin core plugin -->
    <script src="/static/assets/js/jquery.min.js"></script>
    <script src="/static/assets/js/bootstrap.min.js"></script>
    <!-- End core plugin -->

</body>

</html>

