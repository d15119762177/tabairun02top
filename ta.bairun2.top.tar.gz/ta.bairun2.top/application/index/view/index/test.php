<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="{:url('Excel/index')}" method="post" enctype="multipart/form-data">
		<input type="file" name="excel">
		<input type="submit" value="确定">
	</form>
</body>
</html>